package com.example.ighelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class AutoService : AccessibilityService() {

    companion object {
        @Volatile var instance: AutoService? = null
        const val IG = "com.instagram.android"
        const val PREFS = "cfg"

        fun today(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

        fun likesToday(c: Context): Int {
            val p = c.getSharedPreferences(PREFS, MODE_PRIVATE)
            return if (p.getString("day", "") == today()) p.getInt("likes", 0) else 0
        }

        fun savesToday(c: Context): Int {
            val p = c.getSharedPreferences(PREFS, MODE_PRIVATE)
            return if (p.getString("day", "") == today()) p.getInt("saves", 0) else 0
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ui = Handler(Looper.getMainLooper())
    @Volatile var running = false

    private val stepRunnable = Runnable { cycle() }

    // ---------- overlay ----------
    private var wm: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var startBtn: Button? = null
    private var counter: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        if (overlay != null) return
        val p = prefs()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 20, 20, 20))
                cornerRadius = dp(14).toFloat()
            }
        }

        val header = TextView(this).apply {
            text = "IG Helper  ⠿  ▾"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        root.addView(header)

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val sb = Button(this).apply {
            text = "▶ Start"
            isAllCaps = false
            setOnClickListener { if (running) stop() else start() }
        }
        startBtn = sb
        body.addView(sb)

        fun box(label: String, key: String): CheckBox = CheckBox(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isChecked = p.getBoolean(key, true)
            setOnCheckedChangeListener { _, c -> prefs().edit().putBoolean(key, c).apply() }
        }
        body.addView(box("Like", "likeOn"))
        body.addView(box("Save", "saveOn"))
        body.addView(box("Scroll", "scroll"))

        val ct = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f }
        counter = ct
        body.addView(ct)
        root.addView(body)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(180)
        }
        lp = params

        // drag by header, tap header to collapse/expand
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = params.x; oy = params.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) {
                        params.x = ox + dx.toInt()
                        params.y = oy + dy.toInt()
                        wm?.updateViewLayout(root, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val open = body.visibility == View.VISIBLE
                        body.visibility = if (open) View.GONE else View.VISIBLE
                        header.text = if (open) "IG  ▸" else "IG Helper  ⠿  ▾"
                        wm?.updateViewLayout(root, params)
                    }
                }
            }
            true
        }

        overlay = root
        wm?.addView(root, params)
        tick()
    }

    private fun hideOverlay() {
        ui.removeCallbacksAndMessages(null)
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    private fun tick() {
        val p = prefs()
        startBtn?.text = if (running) "⏸ Stop" else "▶ Start"
        counter?.text = "Like ${likesToday(this)}/${p.getInt("likeLimit", 20)}   " +
            "Save ${savesToday(this)}/${p.getInt("saveLimit", 7)}"
        ui.postDelayed({ tick() }, 1000)
    }

    // ---------- service lifecycle ----------
    override fun onServiceConnected() {
        instance = this
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }
    override fun onUnbind(intent: Intent?): Boolean {
        stop()
        hideOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    fun start() {
        running = true
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed(stepRunnable, 1500)
    }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun prefs() = getSharedPreferences(PREFS, MODE_PRIVATE)

    private fun bump(key: String) {
        val p = prefs()
        val day = today()
        if (p.getString("day", "") != day) {
            p.edit().putString("day", day).putInt("likes", 0).putInt("saves", 0).apply()
        }
        p.edit().putInt(key, p.getInt(key, 0) + 1).apply()
    }

    // ---------- main loop ----------
    private fun cycle() {
        if (!running) return
        val p = prefs()
        val likeOn = p.getBoolean("likeOn", true)
        val saveOn = p.getBoolean("saveOn", true)
        val scrollOn = p.getBoolean("scroll", true)

        val likeDone = likeOn && likesToday(this) >= p.getInt("likeLimit", 20)
        val saveDone = !likeOn && saveOn && savesToday(this) >= p.getInt("saveLimit", 7)
        if (likeDone || saveDone) { running = false; return }

        if (rootInActiveWindow?.packageName?.toString() != IG) {
            handler.postDelayed(stepRunnable, 2000)   // wait until Instagram is open
            return
        }

        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()

        if (likeOn) {
            doubleTap(w * 0.5f + jitter(), h * 0.45f + jitter())
            handler.postDelayed({ if (running) bump("likes") }, 300)
        }

        if (saveOn) {
            handler.postDelayed({
                if (running && savesToday(this) < p.getInt("saveLimit", 7)) save(w, h)
            }, 900)
        }

        if (scrollOn) {
            handler.postDelayed({ if (running) swipeUp(w, h) }, 1700)
        }

        val minS = p.getInt("minDelay", 4)
        val maxS = maxOf(p.getInt("maxDelay", 9), minS + 1)
        val wait = 1700L + Random.nextInt(minS * 1000, maxS * 1000) + 800L
        handler.postDelayed(stepRunnable, wait)
    }

    private fun save(w: Float, h: Float) {
        val root = rootInActiveWindow
        val node = root?.let { findSaveNode(it) }
        if (node != null) {
            val d = node.contentDescription?.toString()?.lowercase() ?: ""
            if (d.contains("remove") || d.contains("unsave") || d == "saved") return // already saved
            var n: AccessibilityNodeInfo? = node
            while (n != null && !n.isClickable) n = n.parent
            if (n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) {
                bump("saves")
                return
            }
        }
        tap(w * 0.92f, h * 0.775f)   // fallback: where the bookmark icon sits
        bump("saves")
    }

    private fun findSaveNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val d = node.contentDescription?.toString()?.lowercase()
        if (d == "save" || d == "add to saved" || d == "saved" ||
            d == "remove from saved" || d == "unsave") return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val r = findSaveNode(c)
            if (r != null) return r
        }
        return null
    }

    // ---------- gestures ----------
    private fun jitter() = Random.nextInt(-25, 26).toFloat()

    private fun stroke(x: Float, y: Float, start: Long): GestureDescription.StrokeDescription {
        val path = Path().apply { moveTo(x, y) }
        return GestureDescription.StrokeDescription(path, start, 50)
    }

    private fun tap(x: Float, y: Float) {
        val g = GestureDescription.Builder().addStroke(stroke(x, y, 0)).build()
        dispatchGesture(g, null, null)
    }

    private fun doubleTap(x: Float, y: Float) {
        val g = GestureDescription.Builder()
            .addStroke(stroke(x, y, 0))
            .addStroke(stroke(x, y, 130))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun swipeUp(w: Float, h: Float) {
        val path = Path().apply {
            moveTo(w * 0.5f + jitter(), h * 0.72f)
            lineTo(w * 0.5f + jitter(), h * 0.28f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 260))
            .build()
        dispatchGesture(g, null, null)
    }
}
